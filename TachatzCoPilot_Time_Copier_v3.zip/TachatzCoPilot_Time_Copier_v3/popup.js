const TEST_ITEMS = [
  '19/07/2026 22:00',
  '20/07/2026 05:00',
  '20/07/2026 22:00',
  '21/07/2026 05:00',
  '21/07/2026 22:00',
  '22/07/2026 05:00'
];

const startButton = document.getElementById('startButton');
const stopButton = document.getElementById('stopButton');
const status = document.getElementById('status');

let statusTimer = null;

function setStatus(text) {
  status.textContent = text;
}

async function refreshStatus() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });

    if (!result?.ok) {
      setStatus(`שגיאה: ${result?.error || 'מצב לא ידוע'}`);
      return;
    }

    if (result.lastError) {
      setStatus(
        `הרצף נעצר.\nשגיאת לוח: ${result.lastError}\n` +
        `הועתקו ${result.currentIndex} מתוך ${result.total}.`
      );
      return;
    }

    if (result.running) {
      setStatus(
        `פועל: הועתקו ${result.currentIndex} מתוך ${result.total}.\n` +
        `הערך האחרון: ${result.lastCopied || 'ממתין...'}`
      );
      return;
    }

    if (result.total > 0 && result.currentIndex >= result.total) {
      setStatus(`הבדיקה הסתיימה: הועתקו ${result.total} ערכים.`);
      return;
    }

    setStatus('מוכן לבדיקה.');
  } catch (error) {
    setStatus(`שגיאה: ${error?.message || String(error)}`);
  }
}

function startPolling() {
  if (statusTimer) clearInterval(statusTimer);
  statusTimer = setInterval(refreshStatus, 500);
}

startButton.addEventListener('click', async () => {
  setStatus('מתחיל...');

  const result = await chrome.runtime.sendMessage({
    type: 'START_TEST_SEQUENCE',
    items: TEST_ITEMS,
    intervalMs: 3000
  });

  if (!result?.ok) {
    setStatus(`לא ניתן להתחיל: ${result?.error || 'שגיאה לא ידועה'}`);
    return;
  }

  setStatus(`הרצף התחיל. סך הכול ${result.total} ערכים.`);
  startPolling();
});

stopButton.addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'STOP_SEQUENCE' });
  setStatus('הרצף נעצר.');
  await refreshStatus();
});

refreshStatus();
startPolling();
