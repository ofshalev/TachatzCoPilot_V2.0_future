let timerId = null;
let items = [];
let currentIndex = 0;
let intervalMs = 3000;
let running = false;
let lastCopied = '';
let lastError = '';

function writeClipboard(text) {
  const area = document.getElementById('clipboardArea');

  area.value = String(text || '');
  area.focus();
  area.select();
  area.setSelectionRange(0, area.value.length);

  const copied = document.execCommand('copy');

  window.getSelection()?.removeAllRanges();

  if (!copied) {
    throw new Error('document.execCommand("copy") returned false');
  }
}

function copyCurrentAndScheduleNext() {
  if (!running) return;

  if (currentIndex >= items.length) {
    running = false;
    timerId = null;
    return;
  }

  const text = String(items[currentIndex] || '');

  try {
    writeClipboard(text);
    lastCopied = text;
    lastError = '';
    currentIndex += 1;
  } catch (error) {
    running = false;
    timerId = null;
    lastError = error?.message || String(error);
    return;
  }

  if (currentIndex >= items.length) {
    running = false;
    timerId = null;
    return;
  }

  timerId = setTimeout(copyCurrentAndScheduleNext, intervalMs);
}

function stopSequence() {
  running = false;

  if (timerId) {
    clearTimeout(timerId);
    timerId = null;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target !== 'offscreen') return;

  if (message.type === 'START_SEQUENCE') {
    stopSequence();

    items = Array.isArray(message.items)
      ? message.items.map(value => String(value || '')).filter(Boolean)
      : [];

    intervalMs = Math.max(500, Number(message.intervalMs) || 3000);
    currentIndex = 0;
    lastCopied = '';
    lastError = '';

    if (!items.length) {
      sendResponse({ ok: false, error: 'No values were supplied.' });
      return;
    }

    running = true;
    copyCurrentAndScheduleNext();

    sendResponse({
      ok: true,
      total: items.length,
      intervalMs
    });
    return;
  }

  if (message.type === 'STOP_SEQUENCE') {
    stopSequence();
    sendResponse({ ok: true });
    return;
  }

  if (message.type === 'GET_STATUS') {
    sendResponse({
      ok: true,
      running,
      currentIndex,
      total: items.length,
      lastCopied,
      lastError
    });
  }
});
