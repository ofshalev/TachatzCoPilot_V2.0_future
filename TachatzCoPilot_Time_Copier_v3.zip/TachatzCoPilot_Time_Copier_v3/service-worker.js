const OFFSCREEN_PATH = 'offscreen.html';

async function ensureOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_PATH);

  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [offscreenUrl]
    });

    if (contexts.length > 0) return;
  }

  try {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_PATH,
      reasons: ['CLIPBOARD'],
      justification: 'Copy a user-started sequence of future-event times at fixed intervals.'
    });
  } catch (error) {
    // If the document already exists, createDocument may reject.
    if (!String(error?.message || error).includes('single offscreen document')) {
      throw error;
    }
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === 'START_TEST_SEQUENCE') {
      await ensureOffscreenDocument();
      const result = await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'START_SEQUENCE',
        items: message.items,
        intervalMs: message.intervalMs
      });
      sendResponse(result);
      return;
    }

    if (message?.type === 'STOP_SEQUENCE') {
      await ensureOffscreenDocument();
      const result = await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'STOP_SEQUENCE'
      });
      sendResponse(result);
      return;
    }

    if (message?.type === 'GET_STATUS') {
      await ensureOffscreenDocument();
      const result = await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'GET_STATUS'
      });
      sendResponse(result);
    }
  })().catch(error => {
    sendResponse({
      ok: false,
      error: error?.message || String(error)
    });
  });

  return true;
});
