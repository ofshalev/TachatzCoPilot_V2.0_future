TachatzCoPilot Time Copier v3

Installation
1. Extract this ZIP to a normal folder.
2. In Microsoft Edge, open edge://extensions
3. Remove or disable the earlier test extension.
4. Turn on Developer mode.
5. Click "Load unpacked".
6. Select the extracted TachatzCoPilot_Time_Copier_v3 folder.
7. Reload the TachatzCoPilot GitHub Pages tab.

This version is designed to receive time sequences from TachatzCoPilot itself.
The extension popup still contains the fixed-list test so the background clipboard
engine can also be tested independently.
