const PAGE_SOURCE = 'tachatz-copilot-page';
const EXTENSION_SOURCE = 'tachatz-copilot-extension';

function postToPage(type, payload = {}) {
  window.postMessage({
    source: EXTENSION_SOURCE,
    type,
    ...payload
  }, window.location.origin);
}

window.addEventListener('message', async event => {
  if (event.source !== window) return;
  if (event.origin !== window.location.origin) return;

  const message = event.data;

  if (!message || message.source !== PAGE_SOURCE) return;

  try {
    if (message.type === 'PING_EXTENSION') {
      postToPage('EXTENSION_READY', { version: chrome.runtime.getManifest().version });
      return;
    }

    if (message.type === 'START_TIME_SEQUENCE') {
      const items = Array.isArray(message.items)
        ? message.items.map(value => String(value || '')).filter(Boolean)
        : [];

      const result = await chrome.runtime.sendMessage({
        type: 'START_TEST_SEQUENCE',
        items,
        intervalMs: Number(message.intervalMs) || 3000
      });

      postToPage('SEQUENCE_STARTED', result || {
        ok: false,
        error: 'No response from extension.'
      });
      return;
    }

    if (message.type === 'STOP_TIME_SEQUENCE') {
      const result = await chrome.runtime.sendMessage({
        type: 'STOP_SEQUENCE'
      });

      postToPage('SEQUENCE_STOPPED', result || { ok: true });
      return;
    }

    if (message.type === 'GET_TIME_SEQUENCE_STATUS') {
      const result = await chrome.runtime.sendMessage({
        type: 'GET_STATUS'
      });

      postToPage('SEQUENCE_STATUS', result || {
        ok: false,
        error: 'No status response from extension.'
      });
    }
  } catch (error) {
    postToPage('EXTENSION_ERROR', {
      ok: false,
      error: error?.message || String(error)
    });
  }
});

postToPage('EXTENSION_READY', {
  version: chrome.runtime.getManifest().version
});
